{{ ucfunc("put_docready_start") }}
		
  var objCarousel = jQuery('#{{uc_id}}');
  
  		objCarousel.owlCarousel({
			loop: {{loop}},
            center:{{center}},
            shuffle:{{shuffle}},
            setActiveClassOnMobile:{{active_on_mobile}},
            changeItemOnClick:{{scroll_on_click}},
            rtl:{{rtl}},
            margin:{{margin_between_slides}},                          
            autoplay:{{autoplay}},
            autoplayTimeout:{{autoplay_interval}},
            autoplayHoverPause: {{autoplay_hover_pause}},
            smartSpeed: {{transition_speed}},
            {% if dots_navigation == "false" %}
            dots: false,
            {% endif %}	                            
            {% if dots_navigation == "true" %}
            dots: true,
            {% endif %}	
            {% if arrow_navigation == "false" %}                               
            	nav: false,
            {% endif %}	
            {% if arrow_navigation == "true" %}                               
            	nav: true,
            	navText: ["<i class='{{left_arrow}}'></i>","<i class='{{right_arrow}}'></i>"],
            {% endif %}	
			responsiveClass: true,
			responsive: {
			        0 : {
						items:{{number_of_items_mobile}},
                        slideBy: {{slides_to_change_mobile}},        
					},
					768 : {
						items:{{number_of_items_tablet}},
                        slideBy: {{slides_to_change_tablet}},        
					},
					980 : {
						items:{{number_of_items}},
                        slideBy: {{slides_to_change}},         
					} 
			}
		  });
  
		{{ucfunc("put_remote_parent_js","objCarousel")}}  

{{ ucfunc("put_docready_end") }}