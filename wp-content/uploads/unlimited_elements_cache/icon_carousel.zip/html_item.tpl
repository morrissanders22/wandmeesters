<div class="uc_icon_carousel_container_holder ue-item {{item.item_repeater_class}}">

  {% if item.add_image_background == "true" %}
      <img class="ue-image-background-override" src="{{item.image}}" {{item.image_attributes|raw}}> 
  {% endif %}	

  <div class="uc_icon_carousel_content">
    <div class="ue_ico_title_text_holder">
      {% if show_icon == "true" %}<div class="ue-item-icon">{{item.icon_html|raw}}</div>{% endif %}

      {% if show_title == "true" %}<{{title_html_tag}} class="uc_icon_carousel_title">{{item.title|raw}}</{{title_html_tag}}>{% endif %}

      {% if show_sep == "true" %}
        <span class="title_border" style=""></span>
      {% endif %}	

      {% if show_text == "true" %}<div class="uc_icon_carousel_text">{{item.content|raw}}</div>{% endif %}
    </div>   
      {% if show_button == "true" %}
         <a class="uc_more_btn {{button_hover}}" style="" href="{{item.link|raw}}" {{item.link_html_attributes|raw}}>{{button_text|raw}}</a>
    {% endif %}	

  </div>
</div>