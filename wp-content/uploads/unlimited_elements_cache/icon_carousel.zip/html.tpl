{% if rtl == "false" %}<div class="uc_icon_carousel" style="direction:ltr;" id="{{uc_id}}-wrapper">{% endif %}
{% if rtl == "true" %}<div class="uc_icon_carousel" id="{{uc_id}}-wrapper">{% endif %}	
    
  <div class="uc_carousel owl-carousel {{remote_parent.class}}" id="{{uc_id}}" {{remote_parent.attributes|raw}}>
     {{put_items()}}
  </div>
</div>