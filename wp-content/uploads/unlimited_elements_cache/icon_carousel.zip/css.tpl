#{{uc_id}}-wrapper
{
  min-height:1px;
}
#{{uc_id}} *{
	box-sizing: border-box;
}
#{{uc_id}} .ue-item
{
  overflow:hidden;
  transition:0.5s;
}
.uc_icon_carousel_title
{
	font-size:21px;
}
#{{uc_id}} .uc_icon_carousel_content
{
  position:relative;
}
#{{uc_id}} .uc_icon_carousel_container_holder{
  display:flex;
  flex-direction:column;
}
#{{uc_id}} .uc_icon_carousel_content{
  flex-grow: 1;
  display: flex;
  flex-direction: column;
}

#{{uc_id}} .uc_icon_carousel_content .title_border
{
	display:inline-block;
}

#{{uc_id}} .uc_icon_carousel_content .uc_more_btn
{
	text-decoration:none;
	transition: all 0.5s ease;
    display:inline-block;
    text-align:center;
}


#{{uc_id}} .owl-nav .owl-prev{
    position:absolute;
    display:inline-block;
    text-align:center;
}
#{{uc_id}} .owl-nav .owl-next{
  position:absolute;
  display:inline-block;
  text-align:center;
}


#{{uc_id}} .owl-dots {
overflow:hidden;
text-align:{{dot_alignment}};
}

#{{uc_id}} .owl-dot {
border-radius:50%;
display:inline-block;
}


{% if make_3d == "true" %} 
#{{uc_id}} .ue-item {
	opacity: 0.3;
	transform: scale3d(0.8, 0.8, 1);
	transition: all 0.3s ease-in-out;
}

#{{uc_id}} .active.center .ue-item {
	opacity: 1;
	transform: scale3d(1, 1, 1);
	transition: all 0.3s ease-in-out;
}
{% endif %}




#{{uc_id}} .ue-item-icon
{
  line-height:1em;
  display:inline-flex;
  justify-content:center;
  align-items:center;
  
}

#{{uc_id}} .ue-item-icon svg
{
  height:1em;
  width:1em;
}

#{{uc_id}} .ue-image-background-override
{
  position:absolute;
  top:0px;
  left:0px;
  right:0px;
  bottom:0px;
  height:100%;
  width:100%;
  object-fit: cover;
}